import React from "react";

function ErrorPage() {
  return <div>ERROR! PAGE NOT FOUND</div>;
}

export default ErrorPage;